<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Barner extends Model
{
    protected $table = 'barner';
    public $timestamps = false;
}
