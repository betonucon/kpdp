<?php

function link_html(){
    $data='';

    return $data;
}

function about($id){
    $data=App\About::where('kategori',$id)->first();
    return $data;
}

function sts($id){
    if($id==0){
        $data='<i class="fa fa-check-circle"></i>';
    }
    if($id==1){
        $data='<i class="fa fa-check-circle-o"></i>';
    }
    return $data;
}





?>