<ul class="sidebar-menu" data-widget="tree">
      <li><a href="{{url('home')}}"><i class="fa fa-home text-yellow"></i> Home</a></li>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-folder text-yellow"></i> <span>About</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="{{url('about?act=sekilas')}}"><i class="fa fa-check-circle text-yellow"></i> Sekilas</a></li>
          <li><a href="{{url('about?act=visi')}}"><i class="fa fa-check-circle text-yellow"></i> Visi & Misi</a></li>
          <li><a href="{{url('about?act=corporate')}}"><i class="fa fa-check-circle text-yellow"></i> Corporate</a></li>
          <li><a href="{{url('about?act=sertifikat')}}"><i class="fa fa-check-circle text-yellow"></i> Sertifikat</a></li>
        </ul>
      </li>
      <li><a href="{{url('pengumuman')}}"><i class="fa fa-volume-up text-yellow"></i> Pengumuman</a></li>  
      <li><a href="{{url('barner')}}"><i class="fa fa-clone text-yellow"></i> Barner</a></li>  
      <li><a href="{{url('news')}}"><i class="fa fa-file-sound-o text-yellow"></i> News</a></li>  
      </ul>