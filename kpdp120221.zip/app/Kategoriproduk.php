<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kategoriproduk extends Model
{
    protected $table = 'kategori_produk';
    public $timestamps = false;
}
